import gsap from 'gsap';
// const imagesLoaded = require('imagesloaded');

import { ScrollTrigger } from "gsap/ScrollTrigger";
import { GSDevTools } from "gsap-custom/GSDevTools"
import utils from '../utils';
let { isTouchDevice, onSwipe, Wheel, isMobile, isPortrait, triggerEventOnce } = utils;

gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(GSDevTools);

class Component {
    constructor({ element }) {
        this.element = element;
    }

    init() {

        this.animate();
    }

    animate() {
        const horizontal = document.querySelector('[data-horizontal]');
        const horizontalWrap = horizontal.querySelector('[data-horizontal-img-wrap]');
        const horizontalImg = horizontal.querySelector('[data-horizontal-img]');

        this.horizontalAnimation = gsap.timeline({ paused: true });

        this.horizontalAnimation
            .to(horizontalImg, {
                x: -(horizontalImg.offsetWidth - horizontalWrap.offsetWidth),
                duration: 1,
                ease: 'none'
            })
        
        ScrollTrigger.create({
            scroller: '[data-scroll-container]',
            trigger: horizontal,
            animation: this.horizontalAnimation,
            scrub: 0.5,
            start: "top top+=60",
            end: "+=200%",
            // onUpdate: (self) => console.log(self),
            pin: true,
            pinSpacing: true,
            markers: false,
        });
    }
}

export default function () {

    const componentElement = document.querySelector('[data-horizontal]');

    if(componentElement) {
        let component = new Component({
            element: componentElement
        });

        component.init();
    }
}
