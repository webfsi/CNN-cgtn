import heroTransition from "./heroTransition";
import initHero from "./hero";
import initPart1 from "./part-1";
import horizontal from "./horizontal";
import cta from "./cta";
import listImageScale from "./listImageScale";
import pan from "./pan";
import lightbox from "./lightbox";
import preloader from "./preloader";
import initSplitter from "./splitter";
import hub from "./hub";
import menu from "./menu";
import smoothScroll from "./smoothScroll";

import initCnnBar from './cnnBar';

export default () => {
    smoothScroll();
    preloader();
    hub();
    initHero();
    heroTransition();
    
    lightbox();
    const menuInstance = menu();
    initCnnBar();

    document.addEventListener("preloaderDone", () => {
        initSplitter();
        initPart1();
        listImageScale();
        pan();
        horizontal();
        cta();
        lscroll.update();
    }, { once: true });

    document.addEventListener("transitionFinished", () => {
        heroTransition();

        initSplitter();
        initPart1();
        listImageScale();
        pan();
        horizontal();
        cta();
        menuInstance.initWhiteArea();
        setTimeout(() => {
            console.log(document.querySelector('[data-scroll-container]').offsetHeight);
            window.dispatchEvent(new Event('resize'));
        }, 0)
    }, { once: true });
}