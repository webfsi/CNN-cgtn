import gsap from 'gsap';
// const imagesLoaded = require('imagesloaded');

import { ScrollTrigger } from "gsap/ScrollTrigger";
import { GSDevTools } from "gsap-custom/GSDevTools"
import utils from '../utils';
let { isTouchDevice, onSwipe, Wheel, isMobile, isPortrait, triggerEventOnce } = utils;

gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(GSDevTools);

class Component {
    constructor({ element }) {
        this.element = element;
    }

    init() {

        this.animate();
    }

    animate() {
        this.heroHeader = this.element.querySelector('[data-hero-header]');
        this.heroBg = this.element.querySelector('[data-hero-bg]');
        this.heroShip = this.element.querySelector('[data-hero-ship]');

        this.heroTransition = gsap.timeline({ paused: true });

        this.heroTransition
            .fromTo(this.heroBg, {
                y: 0,
            }, {
                y: -250,
                duration: 1,
            })
            .to(this.heroHeader, {
                y: 150,
                opacity: 0,
                duration: 0.5,
            }, '0')

        if(this.heroShip) {
            this.heroTransition
                .set(this.heroBg, {
                    backgroundColor: '#E1DAD0',
                }, '0.5')
                .fromTo(this.heroShip, {
                    y: 0,
                    x: 0
                }, {
                    y: 150,
                    x: -100,
                    duration: 1,
                }, '0')
        }

        ScrollTrigger.create({
            scroller: '[data-scroll-container]',
            trigger: document.querySelector('[data-hero-wrap]'),
            animation: this.heroTransition,
            scrub: true,
            start: "top top",
            end: "bottom top",
            // onUpdate: (self) => console.log(self),
            pin: false,
            pinSpacing: false,
            markers: false,
        });
    }
}

export default function () {

    const componentElement = document.querySelector('[data-component="hero"]');

    if(componentElement) {
        let component = new Component({
            element: componentElement
        });

        component.init();
    }
}
