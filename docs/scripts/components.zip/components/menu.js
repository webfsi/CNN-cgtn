import gsap from 'gsap';
// const imagesLoaded = require('imagesloaded');

import initHero from "./hero";

import { ScrollTrigger } from "gsap/ScrollTrigger";
import { GSDevTools } from "gsap-custom/GSDevTools"
import utils from '../utils';
// import smoothScroll from './smoothScroll';
let { isTouchDevice, onSwipe, Wheel, isMobile, isPortrait, triggerEventOnce } = utils;

gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(GSDevTools);

class Component {
    constructor({ element }) {
        this.element = element;

        this.transitions = document.querySelectorAll('[data-transition]')

        this.tile = document.querySelector('.tile_hero-wrap');
        this.tilePlaceholder = document.querySelector('.tile-placeholder');
        this.isAnimating = false;
    }

    init() {
        this.animate();
        this.transition();
        this.initWhiteArea();
        this.initStateHandler();
    }

    animate() {
        const self = this;
        this.animattion = gsap.timeline({ paused: true });

        $('.btn-menu').click(function() {
            $('.menu').toggleClass('is-active');
            $(this).toggleClass('is-active');
            
            if($('.menu').hasClass('is-active')) {
                lscroll.stop()
            } else {
                lscroll.start()
            }
        })

        $('.btn.-continue').click(function(e){
            e.preventDefault();

            $('.btn-menu').trigger('click');
        })
    }

    initWhiteArea() {
        document.querySelectorAll('[data-white-area]').forEach((elem) => {
            const animationTrigger = ScrollTrigger.create({
                scroller: "[data-scroll-container]",
                trigger: elem,
                scrub: false,
                start: "top top+=60",
                end: "bottom top",
                pin: false,
                pinSpacing: false,
                markers: false,
                onToggle: (self) => {
                    if (self.isActive) {
                        $('.btn-menu').addClass('-brown');
                    } else {
                        $('.btn-menu').removeClass('-brown');
                    }
                }
            });
        })
    }

    initStateHandler() {
        console.log('initHandler');

        (function(history) {
            var pushState = history.pushState;
            history.pushState = function(state) {
                if (typeof history.onpushstate == "function") {
                    history.onpushstate({
                        state: state
                    });
                }
                return pushState.apply(history, arguments);
            }
        })(window.history);

        window.onpopstate = history.onpushstate = (e) => {
            console.log(e);
            if(e.state) {
                this.loadNext(e.state || e.target.location.href);
                return;
            }

            window.location = e.target.location;
        };
    }

    initTiles() {
        const setTileClip = () => {
            this.transitions.forEach((element) => {
                const tilePlaceholder = element.querySelector('.tile-placeholder');
                const tile = element.querySelector('.tile_hero-wrap');

                let clip = {
                    x: window.innerWidth - tilePlaceholder.offsetWidth,
                    y: window.innerHeight - tilePlaceholder.offsetHeight
                }
    
                gsap.set(tile, {
                    'clipPath': `inset(0px ${clip.x}px ${clip.y}px 0 round 20px)`
                })
            });
        }

        $(window).on('resize', () => {
            if(!this.isAnimating) setTileClip();
        });

        setTileClip();
    }

    transition() {

        this.initTiles();

        const self = this;

        $('[data-transition]').click(function (e) {
            self.currentTransition = e.currentTarget;

            gsap.set(e.currentTarget, {
                zIndex: 100
            });
            const nextUrl = e.currentTarget.getAttribute('href');
            const fullUrl = `${location.origin}${location.pathname}${nextUrl}`;

            window.history.pushState(fullUrl, '', fullUrl);
        })

        $(".read-next_item:not(.-soon), .tile-hover").hover(
            function () {
                $(this).find('.btn').addClass("is-hovered");
            }, function () {
                $(this).find('.btn').removeClass("is-hovered");
            }
        );
    }

    loadNext(nextHref) {
        this.isAnimating = true;

        const tilePlaceholder = this.currentTransition.querySelector('.tile-placeholder');
        const hero = this.currentTransition.querySelector('.hero');
        const heroShip = this.currentTransition.querySelector('.hero_bg-ship');
        const tile = this.currentTransition.querySelector('.tile_hero-wrap');
                    
        const placeholderPos = tilePlaceholder.getBoundingClientRect();

        const heroTimeline = gsap.timeline({ paused: true });

        initHero({
            onLoad: false
        });

        gsap.delayedCall(0.3, () => {
            ev('newPage', {});
        })

        const self = this;
        
        const transitionFunction = 'expo.out';

        heroTimeline
            .set(document.querySelector('.menu_tiles'), {
                'overflow': 'visible'
            })
            .to(tile, {
                'clipPath': `inset(0px 0px 0px 0 round 0px)`,
                x: -placeholderPos.left,
                y: -placeholderPos.top,
                ease: transitionFunction,
                duration: 2
            }, '0')
            .to(heroShip, {
                x: 0,
                y: 0,
                scale: 1,
                ease: transitionFunction,
                duration: 2
            }, '0')
            .to(tilePlaceholder, {
                opacity:0,
                ease: transitionFunction,
                duration: 0.5
            }, '0')
            .to(hero, {
                x: 0,
                y: 0,
                scale:1,
                ease: transitionFunction,
                duration: 2,
                onComplete: () => {
                    // const nextHref = `${location.origin}/contemporary-life/`;

                    fetch(nextHref).then(function (response) {
                        return response.text();
                    }).then((html) => {
                        var parser = new DOMParser();
                        var doc = parser.parseFromString(html, 'text/html');

                        document.querySelector('[data-scroll-container]').outerHTML = doc.querySelector('[data-scroll-container]').outerHTML;
                        gsap.set('.menu', {
                            zIndex: -1,
                        })

                        heroTimeline.revert();

                        // gsap.set(heroTimeline, { clearProps: true });
                        self.isAnimating = false;

                        $('.btn-menu, .menu').removeClass('is-active');
                        
                        setTimeout(()=> {
                            gsap.set('.menu', {
                                zIndex: 3,
                                clearProps: 'all'
                            })
                        }, 700)

                        smoothScroll.destroy();

                        $('.btn-menu').removeClass('is-hidden');

                        setTimeout(()=>{
                            ev('transitionFinished', {});
                        }, 100)

                    }).catch(function (err) {
                        console.warn('Something went wrong.', err);
                    });
                }
            }, '0')

        heroTimeline.play()

        // GSDevTools.create({animation: heroTimeline})

        // gsap.to(tile, {
        //   'clipPath': `inset(0px 0px 0px 0 round 0px)`
        // })
    }

    in() {
        // gsap.from(hubHeaderChars.chars, animationSettings, '+=0.2');

        // gsap.from(hubArticles, {
        //     opacity: 0,
        //     y: 100,
        //     ease: "power4.out",
        //     duration: 1,
        //     stagger: 0.05
        // }, '-=1')
    }

    out() {

    }
}

export default function () {

    // const componentElement = document.querySelector('.menu');

    // if(componentElement) {
        let component = new Component({
            element: document
        });

        component.init();

        return component;
    // }
}
